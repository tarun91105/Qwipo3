import {Component} from 'react'

class UpdateProfile extends Component {
  render() {
    return (
      <div>
        <h1>Update Profile</h1>
      </div>
    )
  }
}

export default UpdateProfile
